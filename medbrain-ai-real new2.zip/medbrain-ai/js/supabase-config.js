/**
 * MedBrain AI - Supabase Configuration
 * 
 * 1. Create project at https://supabase.com
 * 2. Go to Settings → API
 * 3. Copy URL and anon key below
 */

const SUPABASE_URL = 'https://dhetxxozvlvtqkzfymqb.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_Z7TFKpgQPdJdgEfu-49D_g_9V8GYp1y';

// Initialize client (will work after you put real keys)
let supabase = null;

function initSupabase() {
  if (typeof window.supabase !== 'undefined' && SUPABASE_URL !== 'YOUR_SUPABASE_URL') {
    supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
    console.log('Supabase connected');
    return true;
  }
  console.warn('Supabase not configured. Using local mode.');
  return false;
}

// ========== AUTH HELPERS ==========

async function signUp(email, password, fullName, role = 'patient') {
  if (!supabase) return { error: 'Supabase not configured' };
  
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: { full_name: fullName, role: role }
    }
  });
  return { data, error };
}

async function signIn(email, password) {
  if (!supabase) return { error: 'Supabase not configured' };
  
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password
  });
  return { data, error };
}

async function signOut() {
  if (!supabase) return;
  await supabase.auth.signOut();
}

async function getCurrentUser() {
  if (!supabase) return null;
  const { data: { user } } = await supabase.auth.getUser();
  return user;
}

async function getProfile() {
  if (!supabase) return null;
  const user = await getCurrentUser();
  if (!user) return null;
  
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', user.id)
    .single();
    
  return data;
}

// ========== PATIENT HELPERS ==========

async function getPatients() {
  if (!supabase) {
    // Fallback to local
    return window.MedBrainDB ? MedBrainDB.getAll() : [];
  }
  
  const { data, error } = await supabase
    .from('patients')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(100);
    
  return data || [];
}

async function addPatient(patient) {
  if (!supabase) {
    return window.MedBrainDB ? MedBrainDB.add(patient) : false;
  }
  
  const { data, error } = await supabase
    .from('patients')
    .insert([patient])
    .select();
    
  return { data, error };
}

async function getPatientById(id) {
  if (!supabase) return null;
  
  const { data, error } = await supabase
    .from('patients')
    .select('*')
    .eq('patient_id', id)
    .single();
    
  return data;
}

// ========== ACTIVITY LOG (Team Monitoring) ==========

async function logActivity(action, details = {}) {
  if (!supabase) return;
  
  const user = await getCurrentUser();
  if (!user) return;
  
  await supabase.from('activity_logs').insert([{
    user_id: user.id,
    action,
    details
  }]);
}

async function getActivityLogs(limit = 50) {
  if (!supabase) return [];
  
  const { data, error } = await supabase
    .from('activity_logs')
    .select('*, profiles(full_name, role)')
    .order('created_at', { ascending: false })
    .limit(limit);
    
  return data || [];
}

// Make available globally
window.MedBrainAPI = {
  initSupabase,
  signUp,
  signIn,
  signOut,
  getCurrentUser,
  getProfile,
  getPatients,
  addPatient,
  getPatientById,
  logActivity,
  getActivityLogs
};
