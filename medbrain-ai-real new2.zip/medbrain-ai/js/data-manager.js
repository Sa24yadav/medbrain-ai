/**
 * MedBrain AI - Patient Data Manager
 * Supports up to 100 patients with local backup + export/import
 * Version: 1.0
 */

const MedBrainDB = {
  KEY: 'medbrain_patients_v1',
  MAX_PATIENTS: 100,
  VERSION: '1.0',

  // Get all patients
  getAll() {
    try {
      const data = localStorage.getItem(this.KEY);
      return data ? JSON.parse(data) : this._defaultData();
    } catch (e) {
      console.error('Error reading data', e);
      return this._defaultData();
    }
  },

  // Save all patients
  saveAll(patients) {
    if (patients.length > this.MAX_PATIENTS) {
      alert(`Maximum ${this.MAX_PATIENTS} patients allowed. Please delete old records.`);
      return false;
    }
    localStorage.setItem(this.KEY, JSON.stringify(patients));
    return true;
  },

  // Add new patient
  add(patient) {
    const patients = this.getAll();
    if (patients.length >= this.MAX_PATIENTS) {
      alert(`Limit reached: Maximum ${this.MAX_PATIENTS} patients.`);
      return false;
    }
    patient.id = patient.id || 'PID-' + Date.now().toString().slice(-6);
    patient.createdAt = new Date().toISOString();
    patient.updatedAt = new Date().toISOString();
    patients.unshift(patient);
    return this.saveAll(patients);
  },

  // Update patient
  update(id, updates) {
    const patients = this.getAll();
    const index = patients.findIndex(p => p.id === id);
    if (index === -1) return false;
    patients[index] = { ...patients[index], ...updates, updatedAt: new Date().toISOString() };
    return this.saveAll(patients);
  },

  // Delete patient
  remove(id) {
    let patients = this.getAll();
    patients = patients.filter(p => p.id !== id);
    return this.saveAll(patients);
  },

  // Get single patient
  getById(id) {
    return this.getAll().find(p => p.id === id) || null;
  },

  // Search
  search(query) {
    const q = query.toLowerCase();
    return this.getAll().filter(p =>
      p.name?.toLowerCase().includes(q) ||
      p.id?.toLowerCase().includes(q) ||
      p.phone?.includes(q)
    );
  },

  // ========== BACKUP SYSTEM ==========

  // Export full backup as JSON file
  exportBackup() {
    const data = {
      version: this.VERSION,
      exportedAt: new Date().toISOString(),
      totalPatients: this.getAll().length,
      patients: this.getAll(),
      meta: {
        app: 'MedBrain AI',
        maxLimit: this.MAX_PATIENTS
      }
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `medbrain-backup-${new Date().toISOString().slice(0,10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    return true;
  },

  // Import backup from JSON file
  importBackup(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = JSON.parse(e.target.result);
          if (!data.patients || !Array.isArray(data.patients)) {
            reject('Invalid backup file');
            return;
          }
          if (data.patients.length > this.MAX_PATIENTS) {
            reject(`Backup has ${data.patients.length} patients. Max allowed is ${this.MAX_PATIENTS}`);
            return;
          }
          this.saveAll(data.patients);
          resolve(data.patients.length);
        } catch (err) {
          reject('Failed to read backup file');
        }
      };
      reader.onerror = () => reject('File read error');
      reader.readAsText(file);
    });
  },

  // Clear all data (with confirmation)
  clearAll() {
    if (confirm('Are you sure? This will delete ALL patient data permanently.')) {
      localStorage.removeItem(this.KEY);
      return true;
    }
    return false;
  },

  // Stats
  stats() {
    const patients = this.getAll();
    return {
      total: patients.length,
      remaining: this.MAX_PATIENTS - patients.length,
      lastUpdated: patients[0]?.updatedAt || null
    };
  },

  // Default sample data
  _defaultData() {
    return [
      {
        id: 'PID-8821',
        name: 'Ramesh Sharma',
        age: 45,
        gender: 'Male',
        phone: '9876543210',
        chiefComplaint: 'Fever, Headache',
        status: 'Consulted',
        vitals: { temp: 101.2, pulse: 98, bp: '120/80', spo2: 98 },
        createdAt: '2025-05-07T09:30:00',
        updatedAt: '2025-05-07T10:15:00'
      },
      {
        id: 'PID-9104',
        name: 'Anita Verma',
        age: 32,
        gender: 'Female',
        phone: '9876543211',
        chiefComplaint: 'Throat Pain',
        status: 'Upcoming',
        vitals: { temp: 98.6, pulse: 78, bp: '118/76', spo2: 99 },
        createdAt: '2025-05-07T10:00:00',
        updatedAt: '2025-05-07T10:00:00'
      },
      {
        id: 'PID-7653',
        name: 'Mohd. Irfan',
        age: 28,
        gender: 'Male',
        phone: '9876543212',
        chiefComplaint: 'Acidity',
        status: 'Upcoming',
        vitals: { temp: 98.4, pulse: 72, bp: '122/80', spo2: 99 },
        createdAt: '2025-05-07T10:30:00',
        updatedAt: '2025-05-07T10:30:00'
      }
    ];
  }
};

// Make available globally
window.MedBrainDB = MedBrainDB;
