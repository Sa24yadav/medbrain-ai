# MedBrain AI – Real Functional Setup Guide (Option C)

Yeh guide follow karke aap **100 users login + Team monitoring + Live updates** wala system bana sakte ho.

---

## Part 1: Supabase Account Banana (5 minute)

1. Jaao → [https://supabase.com](https://supabase.com)
2. **Start your project** pe click karo
3. GitHub se login karo (recommended)
4. **New Project** banao:
   - Name: `medbrain-ai`
   - Database Password: strong password rakho (save kar lo)
   - Region: **Southeast Asia (Singapore)** ya **Mumbai** (agar available ho)
5. Project create hone do (2 minute)

---

## Part 2: Database Schema Lagana

1. Supabase Dashboard me left side **SQL Editor** pe jao
2. **New query** pe click karo
3. File `supabase/schema.sql` ka **poora content** copy-paste karo
4. **Run** button daba do

Agar koi error aaye toh bata dena.

---

## Part 3: API Keys Lena

1. Supabase Dashboard → **Settings** (left bottom) → **API**
2. Yeh 2 cheezein copy karo:
   - **Project URL**
   - **anon public** key

3. Apne project me `js/supabase-config.js` file kholo
4. Yeh lines update karo:

```js
const SUPABASE_URL = 'https://xxxxx.supabase.co';     // yahan Project URL
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...';  // yahan anon key
```

---

## Part 4: Frontend me Supabase Add Karna

`index.html` ke `<head>` me Tailwind ke baad yeh line add karo:

```html
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
```

Aur body ke end me (baaki scripts se pehle):

```html
<script src="js/supabase-config.js"></script>
```

---

## Part 5: Test Users Banana

Supabase Dashboard → **Authentication** → **Users** → **Add user**

| Email                  | Password    | Role    |
|------------------------|-------------|---------|
| doctor@medbrain.ai     | Doctor@123  | doctor  |
| patient@medbrain.ai    | Patient@123 | patient |
| admin@medbrain.ai      | Admin@123   | admin   |

Phir **Table Editor** → `profiles` table me unka `role` column update kar dena.

---

## Part 6: GitHub + Netlify Live Update

1. Saari updated files GitHub pe push karo
2. Netlify already connected hai toh automatically deploy ho jayega
3. Frontend update se **data nahi hatega** (data Supabase me safe hai)

---

## Part 7: Team Monitoring

- Admin role wale user `activity_logs` dekh sakte hain
- Har important action (login, patient add, prescription) log hota hai
- Aap baad me Admin Dashboard bana sakte ho

---

## Security Notes

- `anon` key frontend me use kar sakte ho
- Row Level Security (RLS) on hai
- Service role key **kabhi** frontend me mat dalna

---

## Next Steps

1. Supabase project banao + schema chalao
2. API keys `supabase-config.js` me daalo
3. Test users banao
4. Login test karo
5. Phir dheere-dheere baaki features (Rx, SOAP, etc.) ko bhi Supabase se connect karte jayenge

---

Kisi step pe problem aaye toh exact error message bhej dena.
